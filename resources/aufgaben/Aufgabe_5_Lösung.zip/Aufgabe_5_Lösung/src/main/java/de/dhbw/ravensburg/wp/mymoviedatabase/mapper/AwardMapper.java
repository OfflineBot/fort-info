package de.dhbw.ravensburg.wp.mymoviedatabase.mapper;

import de.dhbw.ravensburg.wp.mymoviedatabase.dto.AwardDTO;
import de.dhbw.ravensburg.wp.mymoviedatabase.model.Award;
import org.mapstruct.InheritInverseConfiguration;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

import java.util.List;

@Mapper(componentModel = "spring")
public interface AwardMapper {

    @Mapping(source = "yearAwarded", target = "celebrationYear")
    public AwardDTO awardToAwardDTO(Award award);
    public List<AwardDTO> awardsToAwardDTOs(List<Award> awards);

    @InheritInverseConfiguration
    @Mapping(target = "movie", ignore = true)
    public Award awardDTOToAward(AwardDTO awardDTO);
    public List<Award> awardDTOsToAwards(List<AwardDTO> awardDTOs);


}
