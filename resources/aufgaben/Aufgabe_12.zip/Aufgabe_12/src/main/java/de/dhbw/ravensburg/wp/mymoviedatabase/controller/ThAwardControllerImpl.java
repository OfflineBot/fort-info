package de.dhbw.ravensburg.wp.mymoviedatabase.controller;

import de.dhbw.ravensburg.wp.mymoviedatabase.dto.AwardDTO;
import de.dhbw.ravensburg.wp.mymoviedatabase.service.AwardService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.servlet.ModelAndView;

import jakarta.validation.Valid;
import java.util.List;

@Slf4j
@Controller
public class ThAwardControllerImpl implements ThAwardController {

    AwardService awardService;

    public ThAwardControllerImpl(AwardService awardService){
        this.awardService = awardService;
    }

    @Override
    @GetMapping("/awards")
    public ModelAndView showAwards(){
        List<AwardDTO> awards = this.awardService.getAllAwards();

        ModelAndView modelAndView = new ModelAndView("awards");
        modelAndView.addObject("awards", awards);
        AwardDTO tmp = new AwardDTO();
        modelAndView.addObject("award", tmp);
        return modelAndView;
    }

    @Override
    @PostMapping("/awards")
    public ModelAndView addAward(@Valid @ModelAttribute("award") AwardDTO awardDTO,
                                 BindingResult bindingResult){


        ModelAndView modelAndView = new ModelAndView("awards");


        if(!bindingResult.hasErrors()){
            this.awardService.addAward(awardDTO);
            modelAndView.addObject("award", new AwardDTO());

        }else{
            modelAndView.addObject("award", awardDTO);

        }

        List<AwardDTO> awards = this.awardService.getAllAwards();
        modelAndView.addObject("awards", awards);


        return modelAndView;
    }


}
