package de.dhbw.ravensburg.wp.mymoviedatabase.controller;

import de.dhbw.ravensburg.wp.mymoviedatabase.dto.AwardDTO;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.servlet.ModelAndView;

import jakarta.validation.Valid;

public interface ThAwardController {
    @GetMapping("/awards")
    ModelAndView showAwards();

    @PostMapping("/awards")
    ModelAndView addAward(@Valid @ModelAttribute("award") AwardDTO awardDTO,
                          BindingResult bindingResult);
}
