package de.dhbw.ravensburg.wp.mymoviedatabase.mapper;

import de.dhbw.ravensburg.wp.mymoviedatabase.dto.MovieDTO;
import de.dhbw.ravensburg.wp.mymoviedatabase.model.MovieCast;
import de.dhbw.ravensburg.wp.mymoviedatabase.model.Movie;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

import java.util.List;

@Mapper(componentModel = "spring", uses = AwardMapper.class)
public interface MovieMapper {

    @Mapping(target = "castIds", source = "involvedMovieCast")
    MovieDTO movieToMovieDTO(Movie movie);
    List<MovieDTO> moviesToMovieDTOs(List<Movie> movies);

    @Mapping(target = "director", ignore = true)
    @Mapping(target = "involvedMovieCast", ignore = true)
    Movie movieDTOToMovie(MovieDTO movieDTO);
    List<Movie> movieDTOsToMovies(List<MovieDTO> movieDTOs);

    default Long map(MovieCast movieCast){
        return movieCast.getId();
    }

}