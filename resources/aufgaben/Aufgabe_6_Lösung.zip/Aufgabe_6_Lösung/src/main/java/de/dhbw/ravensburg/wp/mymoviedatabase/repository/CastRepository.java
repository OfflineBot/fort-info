package de.dhbw.ravensburg.wp.mymoviedatabase.repository;

import de.dhbw.ravensburg.wp.mymoviedatabase.model.MovieCast;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CastRepository extends JpaRepository<MovieCast, Long> {
}
