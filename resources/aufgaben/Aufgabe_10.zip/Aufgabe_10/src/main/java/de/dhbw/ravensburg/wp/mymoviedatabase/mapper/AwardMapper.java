package de.dhbw.ravensburg.wp.mymoviedatabase.mapper;

import de.dhbw.ravensburg.wp.mymoviedatabase.dto.AwardDTO;
import de.dhbw.ravensburg.wp.mymoviedatabase.model.Award;
import org.mapstruct.InheritInverseConfiguration;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

import java.util.List;

@Mapper(componentModel = "spring")
public interface AwardMapper {


    @Mapping(source = "yearAwarded", target = "celebrationYear")
    AwardDTO awardToAwardDTO(Award award);
    List<AwardDTO> awardsToAwardsDTO(List<Award> awards);

    @InheritInverseConfiguration
    @Mapping(target = "movie", ignore = true)
    Award awardDTOToAward(AwardDTO awardDTO);
    List<Award> awardDTOsToAwards(List<AwardDTO> awardDTOList);
}

