package de.dhbw.ravensburg.wp.mymoviedatabase.model;

import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import jakarta.persistence.*;

@Getter
@Setter
@NoArgsConstructor
@Entity
public class Award {
    @Id
    @GeneratedValue
    private long id;
    private String academy;
    private String category;
    private int yearAwarded;

    @JsonIgnore
    @ManyToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "movie_id")
    private Movie movie;

    public Award(String academy, String category, int yearAwarded){
        this.academy=academy;
        this.category=category;
        this.yearAwarded=yearAwarded;
    }

}
