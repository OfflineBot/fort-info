package de.dhbw.ravensburg.wp.mymoviedatabase.repository;

import de.dhbw.ravensburg.wp.mymoviedatabase.model.Award;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;

public interface AwardRepository extends JpaRepository<Award, Long> {

    List<Award> findByAcademyContaining(String acamdey);

    @Query("SELECT a FROM Award a JOIN a.movie m JOIN m.involvedMovieCast c " +
            "WHERE c.surname = :param1")
    List<Award> findAwardByCast(@Param("param1") String cast);

}
