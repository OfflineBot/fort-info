package de.dhbw.ravensburg.wp.mymoviedatabase.controller;

import de.dhbw.ravensburg.wp.mymoviedatabase.model.Award;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;

import java.util.List;

public interface AwardController {
    public List<Award> getAllAwards();
    public Award getAwardById(@PathVariable("awardId") Long awardId);
    public void removeAwardById(@PathVariable("awardId") Long awardId);
    public Award addAward(@RequestBody Award award);
    public Award updateAwardById(@PathVariable("awardId") Long awardId, @RequestBody Award award);
}
